"use client"

import  from "../frontend/src/main"

export default function SyntheticV0PageForDeployment() {
  return < />
}